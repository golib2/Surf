Bu papkaga rasmlaringizni shu nomlar bilan joylang (nomi va formati muhim emas, .jpg yoki .png bo'lishi mumkin — lekin fayl nomi index.html dagi bilan mos kelishi kerak):

hero.jpg            -> Bosh (hero) qismidagi katta fon rasmi
pkg-1.jpg .. pkg-6.jpg   -> "I pacchetti più popolari" bo'limidagi 6 ta karta rasmi
dest-1.jpg .. dest-6.jpg -> "Destinazioni" bo'limidagi 6 ta rasm
newsletter-bg.jpg   -> Newsletter bo'limining fon rasmi

Agar boshqa nom bilan saqlamoqchi bo'lsangiz, index.html faylida tegishli
<img src="images/...">  qatoridagi nomni ham o'zgartiring.
